# data-mining
The code consists of initial phases of data extraction from e-commerce sites.
