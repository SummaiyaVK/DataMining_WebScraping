import bs4 as bs
from bs4 import BeautifulSoup
import requests

def getproductlink(main_url,url,tag,tag_class,sub_tag,sub_tag_class):
    try:
        amazon_request = requests.get(url)
        soup = BeautifulSoup(amazon_request.text, 'lxml')
    except:
        print("Could access source page")
    try:
        tag_l = soup.find_all(str(tag),{"class":str(tag_class)})
        st ="\n".join(map(str,tag_l))
        lin = BeautifulSoup(st,'lxml')
        if tag_l:
            link = lin.find_all(str(sub_tag),{"class":str(sub_tag_class)})
    except:
        print("Tag/link not found. Probable tag/class-mismatch error.")
    try:
        l = []
        if link:
            for i in link:
                atag = i.find_all('a')
                if "http" in atag[0]['href']:
                    l.append(atag[0]['href'])
                if "http" not in atag[0]['href'] and atag[0]['href']:
                    l.append(main_url+atag[0]['href'])
    except:
        print("Cound not find the Sub_tag/link")    
    s=set(l)
    j=0
    if s:
        for i in s:
            #print(str(j)+" : "+i)
            j += 1
    return s
    
          

#Testing
"""
getproductlink("https://www.amazon.in","https://www.amazon.in/digital-slr-cameras/b/ref=sd_allcat_sbc_tvelec_dslr?ie=UTF8&node=1389177031","div","a-row s-result-list-parent-container","div","s-item-container")
print('amazon-over')
getproductlink("https://www.flipkart.com","https://www.flipkart.com/mobiles/pr?sid=tyy%2F4io&p%5B%5D=facets.brand%255B%255D%3DApple&p%5B%5D=facets.availability%255B%255D%3DExclude%2BOut%2Bof%2BStock&otracker=clp_metro_expandable_1_1.metroExpandable.METRO_EXPANDABLE_iPhone_apple-products-store_44444444444444444444444444444444444444444490ff40fd-a46b-4a40-9440-fbe783136afb_DesktopSite&fm=neo%2Fmerchandising&iid=M_7a8d634c-bd86-4742-b4c4-f0a5966b4bc1_1.90ff40fd-a46b-4a40-9440-fbe783136afb_DesktopSite&ppt=Homepage&ppn=Homepage&ssid=9o20v86neo0000001536758749808","div","_1HmYoV _35HD7C col-10-12","div","_1UoZlX")
"""
